package at.windesign.application.serie;

import org.zkoss.web.fn.ServletFns;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.Label;
import org.zkoss.zul.Window;

public class serieDetailsForwardComposer extends GenericForwardComposer<Component>
{
	private static final long serialVersionUID = 1L;

	@Wire
	private Window resultWin;

	@Wire
	protected Label title;

	private serie m_serie;

	@Override
	public void doAfterCompose(Component comp) throws Exception
	{
		super.doAfterCompose(comp);

//		String uri = ServletFns.encodeURL("http://www.freeimageslive.com/galleries/space/earth/pics/a08_h_15_2561.gif");
//		String format = "background-image:url('%1$s'); border: 'none'; background-repeat:repeat-y;";
//		String style = String.format(format, uri);
		String uri = ServletFns.encodeURL("http://www.freeimageslive.com/galleries/space/earth/pics/a08_h_15_2561.gif");
		String format = "background-image:url('%1$s'); border: 'none'; background-repeat:repeat-y;";
		String style = String.format(format, uri);
		resultWin.setStyle(style);
//		resultWin.setContentStyle("\"background-image:url('http://www.freeimageslive.com/galleries/space/earth/pics/a08_h_15_2561.gif');background-repeat: no-repeat;-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;\"  width=\"800px\" height=\"750px\"");
/*
		if(arg.containsKey("serie"))
			m_serie = (serie) arg.get("serie");
		else
			resultWin.detach();

		title.setValue(m_serie.getSeriesName());
*/
	}
}