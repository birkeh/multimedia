package at.windesign.application;

import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.NotifyChange;

import java.util.List;
import java.util.UUID;

public class EventViewModel
{

	private at.windesign.application.EventDAO eventDao = new at.windesign.application.EventDAO();

	private at.windesign.application.TodoEvent selectedEvent, newEvent = new at.windesign.application.TodoEvent();

	public at.windesign.application.TodoEvent getSelectedEvent()
	{
		return selectedEvent;
	}

	public void setSelectedEvent(at.windesign.application.TodoEvent selectedEvent)
	{
		this.selectedEvent = selectedEvent;
	}

	public at.windesign.application.TodoEvent getNewEvent()
	{
		return newEvent;
	}

	public void setNewEvent(at.windesign.application.TodoEvent newEvent)
	{
		this.newEvent = newEvent;
	}

	public List<at.windesign.application.TodoEvent> getEvents()
	{
		return eventDao.findAll();
	}

	@Command("add")
	@NotifyChange("events")
	public void add()
	{
		this.newEvent.setId(UUID.randomUUID().toString());
		eventDao.insert(this.newEvent);
		this.newEvent = new at.windesign.application.TodoEvent();
	}

	@Command("update")
	@NotifyChange("events")
	public void update()
	{
		eventDao.update(this.selectedEvent);
	}

	@Command("delete")
	@NotifyChange({
			"events",
			"selectedEvent"
	})
	public void delete()
	{
		//shouldn't be able to delete with selectedEvent being null anyway
		//unless trying to hack the system, so just ignore the request
		if(this.selectedEvent != null)
		{
			eventDao.delete(this.selectedEvent);
			this.selectedEvent = null;
		}
	}
}
